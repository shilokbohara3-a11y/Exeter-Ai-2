# EXTER AI — Netlify version

This version fixes the Vercel/Netlify mismatch. The browser calls `/.netlify/functions/chat`, and Netlify runs `netlify/functions/chat.mjs`.

## Deploy/update on Netlify
1. Replace the files in the GitHub repository connected to your Netlify project with the contents of this ZIP. Keep the folder structure.
2. Commit the changes to the repository's production branch. Netlify should build and publish automatically.
3. In Netlify → Project configuration → Environment variables, add `HF_TOKEN` with your NEW Hugging Face access token. Never put the token in frontend code or GitHub.
4. Add `HF_MODEL` only if needed; default is `Qwen/Qwen2.5-7B-Instruct`.
5. After adding/changing environment variables, trigger a fresh deploy so the function receives them.
6. Open the published `.netlify.app` site and test a message.

## Local development
`npm install` then `npm run dev` starts only the frontend. Netlify functions require the Netlify CLI (`npx netlify dev`) and `HF_TOKEN` in a local `.env` file. Do not commit `.env`.

## Important
Revoke the token previously pasted into chat and use a replacement. Do not share the new token with anyone. Hugging Face model access/availability may vary by account and model provider.
