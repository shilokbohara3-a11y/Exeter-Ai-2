# EXTER — AI workspace

A dark React + Tailwind chat interface with conversation history and streamed Hugging Face responses. The Hugging Face token is used only by the Vercel serverless function.

## Requirements
- Node.js 20+
- A Hugging Face account and an access token with permission to call Inference Providers
- A Vercel account

## Run locally
1. Extract the ZIP and open this folder in a terminal.
2. Install dependencies: `npm install`
3. Copy `.env.example` to `.env` and add your token:
   ```env
   HF_TOKEN=hf_your_real_token
   HF_MODEL=Qwen/Qwen2.5-7B-Instruct
   ```
4. Start the app: `npm run dev`

Vite serves the frontend at `http://localhost:5173`. To test the `/api/chat` serverless endpoint locally, use Vercel CLI instead:
```bash
npm install -g vercel
vercel dev
```

## Deploy free on Vercel
1. Push this folder to a GitHub repository.
2. In Vercel, choose **Add New → Project** and import the repository.
3. Keep the default Vite build settings (`npm run build`, output directory `dist`).
4. In **Project → Settings → Environment Variables**, add:
   - `HF_TOKEN` = your Hugging Face access token
   - `HF_MODEL` = `Qwen/Qwen2.5-7B-Instruct` (optional)
5. Deploy or redeploy after adding the variables.

Do not put the token in frontend code, `VITE_` variables, GitHub, or a public repository file. If it was exposed, revoke it and create a new one.

## Notes
- The app stores chat history in this browser's local storage; it is not synced between devices.
- The chat endpoint streams server-sent events from the Hugging Face Inference client.
- Model availability, provider routing, speed, and free quotas depend on Hugging Face's current offering and account. If the selected model is unavailable, set `HF_MODEL` to another chat-completion model available to your account.
- This starter has no user accounts or server-side conversation database. Add authentication and persistent storage before using it for private multi-user deployments.
