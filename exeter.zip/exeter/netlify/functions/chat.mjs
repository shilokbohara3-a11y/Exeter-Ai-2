import { InferenceClient } from "@huggingface/inference";

const SYSTEM_PROMPT = `You are EXTER, a helpful, capable AI assistant. Give accurate, thoughtful answers. Explain clearly, follow the user's requested format, and write clean, working code when asked. If unsure, say so instead of inventing facts.`;

export default async (request) => {
  if (request.method !== "POST") {
    return Response.json({ error: "Use POST to send a message." }, { status: 405 });
  }
  if (!process.env.HF_TOKEN) {
    return Response.json({ error: "EXTER is not connected yet. Add HF_TOKEN in Netlify environment variables, then redeploy." }, { status: 500 });
  }
  try {
    const body = await request.json();
    const messages = Array.isArray(body.messages) ? body.messages : [];
    const safeMessages = messages
      .filter((m) => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-20)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 12000) }));
    if (!safeMessages.length || safeMessages[safeMessages.length - 1].role !== "user") {
      return Response.json({ error: "Send a message to start chatting." }, { status: 400 });
    }
    const client = new InferenceClient(process.env.HF_TOKEN);
    const result = await client.chatCompletion({
      model: process.env.HF_MODEL || "Qwen/Qwen2.5-7B-Instruct",
      messages: [{ role: "system", content: SYSTEM_PROMPT }, ...safeMessages],
      max_tokens: 1200,
      temperature: 0.65
    });
    const answer = result.choices?.[0]?.message?.content;
    if (!answer) throw new Error("The AI model returned an empty response. Try again in a moment.");
    return Response.json({ answer });
  } catch (error) {
    console.error("EXTER function error:", error);
    const message = error?.message || "The AI service could not complete this request.";
    return Response.json({ error: message }, { status: 502 });
  }
};
