import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowUp, Bot, ChevronDown, Code2, Command, Copy, Menu, MessageSquarePlus,
  MoreHorizontal, PanelLeftClose, Plus, Search, Settings2, Sparkles, Trash2,
  UserRound, X, Zap
} from "lucide-react";
import "./style.css";

const starterPrompts = [
  { icon: Code2, title: "Build something", text: "Create a responsive React landing page with a clean layout." },
  { icon: Sparkles, title: "Explore an idea", text: "Give me 5 creative app ideas I could build as a beginner." },
  { icon: Zap, title: "Learn faster", text: "Explain how APIs work with a simple real-world example." }
];

const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const shortTitle = (s) => s.trim().slice(0, 34) || "New conversation";

function App() {
  const [chats, setChats] = useState(() => {
    try { return JSON.parse(localStorage.getItem("exter-chats") || "[]"); } catch { return []; }
  });
  const [activeId, setActiveId] = useState(null);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState("");
  const endRef = useRef(null);
  const textareaRef = useRef(null);
  const abortRef = useRef(null);

  const activeChat = chats.find((c) => c.id === activeId) || null;
  const messages = activeChat?.messages || [];
  const isEmpty = messages.length === 0;

  useEffect(() => localStorage.setItem("exter-chats", JSON.stringify(chats)), [chats]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, busy]);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 2400);
    return () => clearTimeout(timer);
  }, [toast]);

  const updateMessages = (id, next) => setChats((old) => old.map((c) =>
    c.id === id ? { ...c, messages: typeof next === "function" ? next(c.messages) : next, updatedAt: Date.now() } : c
  ));

  function newChat() {
    abortRef.current?.abort();
    setBusy(false);
    const id = makeId();
    setChats((old) => [{ id, title: "New conversation", messages: [], updatedAt: Date.now() }, ...old]);
    setActiveId(id);
    setInput("");
    if (window.innerWidth < 760) setSidebarOpen(false);
    setTimeout(() => textareaRef.current?.focus(), 50);
  }

  function deleteChat(id, event) {
    event?.stopPropagation();
    setChats((old) => old.filter((c) => c.id !== id));
    if (activeId === id) setActiveId(null);
  }

  async function sendMessage(raw = input) {
    const text = raw.trim();
    if (!text || busy) return;
    let chat = activeChat;
    if (!chat) {
      const id = makeId();
      chat = { id, title: shortTitle(text), messages: [], updatedAt: Date.now() };
      setChats((old) => [chat, ...old]);
      setActiveId(id);
    }
    const id = chat.id;
    const nextMessages = [...chat.messages, { role: "user", content: text }, { role: "assistant", content: "" }];
    setChats((old) => {
      const exists = old.some((c) => c.id === id);
      const updated = old.map((c) => c.id === id ? {
        ...c, title: c.messages.length ? c.title : shortTitle(text), messages: nextMessages, updatedAt: Date.now()
      } : c);
      return exists ? updated : [{ ...chat, title: shortTitle(text), messages: nextMessages }, ...updated];
    });
    setInput("");
    setBusy(true);
    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const history = nextMessages.slice(0, -1).map(({ role, content }) => ({ role, content }));
      const response = await fetch("/.netlify/functions/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: history }),
        signal: controller.signal
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
      const answer = data.answer || "The AI returned an empty response. Please try again.";
      updateMessages(id, (old) => old.map((m, i) => i === old.length - 1 ? { ...m, content: answer } : m));
    } catch (error) {
      if (error.name !== "AbortError") {
        updateMessages(id, (old) => old.map((m, i) => i === old.length - 1 ? { ...m, content: `**Something went wrong.** ${error.message}` } : m));
      }
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  }

  function onKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  }

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); setToast("Copied to clipboard"); }
    catch { setToast("Copy not available in this browser"); }
  }

  const filteredChats = useMemo(() => chats.filter((c) => c.title.toLowerCase().includes(search.toLowerCase())), [chats, search]);

  return (
    <div className="app-shell">
      {sidebarOpen && <aside className="sidebar">
        <div className="brand-row">
          <div className="brand-mark"><span>e</span></div>
          <span className="brand-name">EXTER</span>
          <button className="icon-btn sidebar-collapse" aria-label="Close sidebar" onClick={() => setSidebarOpen(false)}><PanelLeftClose size={17}/></button>
        </div>
        <button className="new-chat" onClick={newChat}><Plus size={17}/> <span>New chat</span><kbd>⌘ K</kbd></button>
        <div className="side-search"><Search size={15}/><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search chats"/></div>
        <div className="history-label">YOUR WORKSPACE</div>
        <div className="chat-list">
          {filteredChats.length === 0 ? <div className="empty-history">{search ? "No matching chats" : "Your conversations will appear here."}</div> :
            filteredChats.map((chat) => <button key={chat.id} className={`history-item ${activeId === chat.id ? "selected" : ""}`} onClick={() => { setActiveId(chat.id); if (window.innerWidth < 760) setSidebarOpen(false); }}>
              <MessageSquarePlus size={15}/><span>{chat.title}</span>
              <span className="history-delete" onClick={(e) => deleteChat(chat.id, e)}><Trash2 size={14}/></span>
            </button>)}
        </div>
        <div className="sidebar-bottom">
          <div className="profile-avatar">E</div>
          <div className="profile-copy"><strong>EXTER workspace</strong><span>Personal space</span></div>
          <button className="icon-btn" title="Settings"><Settings2 size={17}/></button>
        </div>
      </aside>}

      <main className="main-panel">
        <header className="topbar">
          <div className="top-left">
            {!sidebarOpen && <button className="icon-btn" onClick={() => setSidebarOpen(true)} aria-label="Open sidebar"><Menu size={19}/></button>}
            <span className="mobile-brand">EXTER</span>
            <div className="model-pill"><span className="status-dot"></span> Hugging Face <ChevronDown size={14}/></div>
          </div>
          <div className="top-right"><span className="secure-label"><span className="secure-dot"></span> Private workspace</span><button className="icon-btn" title="More"><MoreHorizontal size={20}/></button></div>
        </header>

        <section className={`conversation ${isEmpty ? "welcome-state" : ""}`}>
          {isEmpty ? <div className="welcome-content">
            <div className="welcome-symbol"><Sparkles size={24}/></div>
            <div className="eyebrow">YOUR AI WORKSPACE</div>
            <h1>Think beyond<br/><span>the ordinary.</span></h1>
            <p>Ideas, answers, and code — all in one focused space.</p>
            <div className="prompt-grid">
              {starterPrompts.map(({ icon: Icon, title, text }) => <button className="prompt-card" key={title} onClick={() => sendMessage(text)}>
                <span className="prompt-icon"><Icon size={17}/></span><strong>{title}</strong><span>{text}</span><ArrowUp className="prompt-arrow" size={15}/>
              </button>)}
            </div>
          </div> : <div className="message-column">
            {messages.map((m, i) => <article className={`message-row ${m.role}`} key={i}>
              <div className={`message-avatar ${m.role}`}>{m.role === "assistant" ? <span className="mini-mark">e</span> : <UserRound size={16}/>}</div>
              <div className="message-body">
                <div className="message-author">{m.role === "assistant" ? "EXTER" : "You"}</div>
                <div className="message-text">{m.content ? <MessageContent text={m.content}/> : <span className="typing"><i></i><i></i><i></i></span>}</div>
                {m.role === "assistant" && m.content && <button className="copy-btn" onClick={() => copyText(m.content)}><Copy size={13}/> Copy</button>}
              </div>
            </article>)}
            <div ref={endRef}/>
          </div>}
        </section>

        <footer className="composer-area">
          <div className="composer">
            <textarea ref={textareaRef} rows="1" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={onKeyDown} placeholder="Message EXTER..." />
            <div className="composer-bottom">
              <div className="composer-tools"><button className="tool-chip" title="Code mode"><Code2 size={15}/> <span>Code</span></button><span className="composer-hint">Shift + Enter for a new line</span></div>
              {busy ? <button className="send-btn stop-btn" onClick={() => abortRef.current?.abort()} title="Stop generating"><span className="stop-square"></span></button> :
                <button className="send-btn" onClick={() => sendMessage()} disabled={!input.trim()} aria-label="Send message"><ArrowUp size={19}/></button>}
            </div>
          </div>
          <div className="disclaimer">EXTER can make mistakes. Verify important information.</div>
        </footer>
      </main>
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}

function MessageContent({ text }) {
  // Lightweight renderer: preserves code blocks and line breaks without injecting HTML.
  const parts = text.split(/```/g);
  return <div>{parts.map((part, i) => i % 2 === 1 ?
    <pre className="code-block" key={i}><code>{part.replace(/^[a-zA-Z0-9+#.-]+\n/, "")}</code></pre> :
    <span className="plain-part" key={i}>{part.split("\n").map((line, j) => <React.Fragment key={j}>{line}{j < part.split("\n").length - 1 && <br/>}</React.Fragment>)}</span>)}</div>;
}

createRoot(document.getElementById("root")).render(<App/>);